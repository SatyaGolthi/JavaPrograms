package com.cg.evm.dto;

import java.time.LocalDate;

public class Employee {

		private int empid;
		private String name;
		private String location;
		private LocalDate joindate;
		private double salary;
		
	
		public int getEmpid() {
			return empid;
		}
		public  void setEmpid(int empid) {
			this.empid = empid;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getLocation() {
			return location;
		}
		public void setLocation(String location) {
			this.location = location;
		}
		public LocalDate getJoindate() {
			return joindate;
		}
		public void setJoindate(LocalDate joindate) {
			this.joindate = joindate;
		}
		public double getSalary() {
			return salary;
		}
		public void setSalary(double salary) {
			this.salary = salary;
		}


}
