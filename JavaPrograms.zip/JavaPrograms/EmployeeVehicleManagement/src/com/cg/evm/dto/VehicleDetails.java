package com.cg.evm.dto;

public class VehicleDetails {
	
		private int vehicleCode;
		private String vehicleNumber;
		private String vehicleType;
		private int empid;
		public int getVehicleCode() {
			return vehicleCode;
		}
		public void setVehicleCode(int vehicleCode) {
			this.vehicleCode = vehicleCode;
		}
		public String getVehicleNumber() {
			return vehicleNumber;
		}
		public void setVehicleNumber(String vehicleNumber) {
			this.vehicleNumber = vehicleNumber;
		}
		public String getVehicleType() {
			return vehicleType;
		}
		public void setVehicleType(String vehicleType) {
			this.vehicleType = vehicleType;
		}
		public int getEmpid() {
			return empid;
		}
		public void setEmpid(int empid) {
			this.empid = empid;
		}
		
}
