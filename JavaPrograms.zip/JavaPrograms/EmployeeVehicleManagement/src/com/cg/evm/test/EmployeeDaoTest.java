package com.cg.evm.test;


import junit.framework.Assert;

import com.cg.evm.dao.VehicleDaoImpl;
import com.cg.evm.dto.Employee;
import com.cg.evm.dto.VehicleDetails;
import com.cg.evm.exception.VehicleException;
import com.cg.evm.util.DatabaseConnection;


public class EmployeeDaoTest {
	@Test(expected=VehicleException.class)
	public void InvalidEmployeeIDCheck() throws VehicleException
	{
		VehicleDetails v=new VehicleDetails();
		VehicleDaoImpl dao=new VehicleDaoImpl();
		v.setEmpid(10);
		dao.addVehicleDetails(v);
	}
	
	@Test
	public void testSetName()
	
	{
		Employee emp=new Employee();
		String expected="Satya";
		emp.setName(expected);
		String actual=emp.getName();
		Assert.assertEquals("Working",expected,actual);
		
	}

}
