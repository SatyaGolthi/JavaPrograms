package com.cg.evm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.evm.dto.VehicleDetails;
import com.cg.evm.exception.VehicleException;
import com.cg.evm.util.DatabaseConnection;

public class VehicleDaoImpl implements VehicleDao{

	@Override
	public int addVehicleDetails(VehicleDetails vehicle) throws VehicleException {
		Connection con= DatabaseConnection.getConnection();
		String sql="insert into employee_vehicle_registration"
				+ " (vehicle_code,empid,vehicle_type,vehicle_no) "
				+ " values(vehicle_code_seq.nextval,?,?,?)";
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setInt(1,vehicle.getEmpid());
			ps.setString(2, vehicle.getVehicleType());
			ps.setString(3, vehicle.getVehicleNumber());
			
			int r= ps.executeUpdate();
			if(r==1){
					Statement s=con.createStatement();
					String query=
							"select vehicle_code_seq.currval from dual ";
					ResultSet rs= s.executeQuery(query);
					if(rs.next())
					{
						int vid= rs.getInt(1);
						return vid;
					}
					else
					return 0;
			}
			else return 0;
		} catch (SQLException e) {
			throw new VehicleException("Employee id does not exist" );
		}
	}

	@Override
	public List<VehicleDetails> getVehicleDetails(int empid) throws VehicleException {
			
		List<VehicleDetails> list= new ArrayList<VehicleDetails>();
		
		String sql="select vehicle_code,vehicle_type,vehicle_no "
				+ " from employee_vehicle_registration "
				+ "  where empid=?";
		Connection con= DatabaseConnection.getConnection();
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setInt(1, empid);
			
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				VehicleDetails vehicle= new VehicleDetails();
				String type=rs.getString("vehicle_type");
				String vNo= rs.getString("vehicle_no");
				int vcode= rs.getInt("vehicle_code");
				
				vehicle.setVehicleCode(vcode);
				vehicle.setVehicleNumber(vNo);
				vehicle.setVehicleType(type);
				
				list.add(vehicle);
		}
		} catch (SQLException e) {
			throw new VehicleException(e.getMessage());
		}
		return list;
	
	}



@Override
public List<VehicleDetails> getVehicleDetails(String vehicle_type)
		throws VehicleException {
List<VehicleDetails> list= new ArrayList<VehicleDetails>();
	
	String sql="select vehicle_code,vehicle_no "
			+ " from employee_vehicle_registration "
			+ "  where vehicle_type=?";
	Connection con= DatabaseConnection.getConnection();
	try {
		PreparedStatement ps= con.prepareStatement(sql);
		
		ps.setString(1, vehicle_type);
		
		ResultSet rs= ps.executeQuery();
		while(rs.next()){
			VehicleDetails vehicle= new VehicleDetails();
			String vNo= rs.getString("vehicle_no");
			int vcode= rs.getInt("vehicle_code");
			
			vehicle.setVehicleCode(vcode);
			vehicle.setVehicleNumber(vNo);
			
			list.add(vehicle);
	}
	} catch (SQLException e) {
		throw new VehicleException(e.getMessage());
	}
	return list;

	
}



}

















