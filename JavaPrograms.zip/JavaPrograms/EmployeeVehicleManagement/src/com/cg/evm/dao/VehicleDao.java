package com.cg.evm.dao;

import java.util.List;

import com.cg.evm.dto.VehicleDetails;
import com.cg.evm.exception.VehicleException;

public interface VehicleDao {
	public int addVehicleDetails(VehicleDetails vehicle)throws VehicleException;
	public   List<VehicleDetails>  getVehicleDetails(String vehicle_type) throws VehicleException;
	List<VehicleDetails> getVehicleDetails(int empid) throws VehicleException;
	
	

}
