import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.zone.ZoneRulesException;
import java.util.Scanner;

public class Date_Operation {

	public void getdiffBetweeTodayAnd()
	{
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a date in dd-mm-yyyy");
		
		LocalDate todaysdate = LocalDate.now();
		DateTimeFormatter dateformat = DateTimeFormatter.ofPattern("dd-mm-yyyy");

		LocalDate date = LocalDate.parse(in.next(), dateformat);
		Period P = date.until(todaysdate);

		System.out.println("Diffrence Between Dates are :\n "+ P.getDays()+" Days \n"
				+ P.getMonths()+" Months\n"+P.getYears()+" Years");
		in.close();
	}
	
	public void getdiffBetweenTwoDates()
	{
		Scanner in = new Scanner(System.in);
		DateTimeFormatter dateformat = DateTimeFormatter.ofPattern("dd-mm-yyyy");
		System.out.println("Enter a date 1 in dd-mm-yyyy");
		LocalDate date1 = LocalDate.parse(in.next(), dateformat);
		System.out.println("Enter a date 2 in dd-mm-yyyy");
		LocalDate date2 = LocalDate.parse(in.next(), dateformat);
		Period P = date1.until(date2);
		System.out.println("Diffrence Between Dates are :\n "+ P.getDays()+" Days \n"
				+ P.getMonths()+" Months\n"+P.getYears()+" Years");
		in.close();
		
	}
	
	public void calculateWarrentyDate()
	{
		Scanner in = new Scanner(System.in);
		LocalDate todaysdate = LocalDate.now();
		DateTimeFormatter dateformat = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		System.out.println("Enter a date 1 in dd-mm-yyyy");
		LocalDate purchasedate = LocalDate.parse(in.next(), dateformat);
		System.out.println("Enter Warrenty Period in PnYnMnD Format eg for 1 year 6 Month P1Y6M0D");
		LocalDate date2 = LocalDate.parse(in.next(), dateformat);
		Period P = Period.parse(in.next());
		purchasedate=purchasedate.plus(P);
		System.out.println("Warrenty Date Ends at "+ purchasedate);
		in.close();
	}
	
	public void timeZone()
	{
		
		
		Scanner in = new Scanner(System.in);
		try {
		ZoneId zone = ZoneId.of(in.next());
		LocalDateTime date = LocalDateTime.now(zone);
		System.out.println("The fortmat for time zone you Selected is "+ date );
		in.close();
		}catch(ZoneRulesException e)
		{
			System.out.println("Incorrect Time Zone Entered");
			e.getStackTrace();
		}
	}
	
	
	public static void main(String[] args) throws ParseException{
		
		
		Date_Operation Do = new Date_Operation();
		Do.calculateWarrentyDate();
	//	Do.timeZone();
	}

}
