package com.capgemini.contactbook.ui;

import java.util.List;
import java.util.Scanner;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;


public class client {
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		int enquiryId;
		String fName,lName,contactNo,pLocation,pDomain;
		ContactBookService service=new ContactBookServiceImpl();
		System.out.println("**********Global Recruitments**********");
		System.out.println("Choose an operation");
		System.out.println("1.Enter Enquiry Details");
		System.out.println("2.View Enquiry Details on Id");
		System.out.println("0.Exit");
		int choice= sc.nextInt();
		switch(choice){
		case 1:
			System.out.println("Enter First Name : ");
			fName=sc.next();
			System.out.println("Enter Last Name : ");
			lName=sc.next();
			System.out.println("Enter Contact Number : ");
			contactNo=sc.next();
			System.out.println("Enter Preferred Domain : ");
			pDomain=sc.next();
			System.out.println("Enter Preferred Location : ");
			pLocation=sc.next();
			EnquiryBean b1=new EnquiryBean();
			b1.setfName(fName);
			b1.setlName(lName);
			b1.setContactNo(contactNo);
			b1.setpDomain(pDomain);
			b1.setpLocation(pLocation);
			ContactBookService ps= new ContactBookServiceImpl();
			boolean res= ps.isValidEnquiry(b1);
			System.out.println(res);
			
			if(res==true){
					int id= ps.addEnquiry(b1);
					System.out.println("Thank you"+" "  +fName+" "+lName +" "  +"your Unique Id is"+" "   +enquiryId +" "  +"we will contact you shortly");
			}
			else
			System.out.println("Invalid details entered....");
			
		   break;
		
		
	


	case 2:
		System.out.println("Enter enquiryId:");
		enquiryId=sc.nextInt();
		 EnquiryBean  enqury=new EnquiryBean();
		 List<EnquiryBean> list=service.getEnquiryDetails(enquiryId);
			if(list==null){
				System.out.println("Sorry no details found!!");
			}
		
	
				
	case 3:
	
		System.out.println("Thank you selecting us!!");
		
		
		}
	}
}
	


