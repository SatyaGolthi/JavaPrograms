package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.util.DatabaseConnection;


public class ContactBookDaoImpl implements ContactBookDao {

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException{
		int enquiryId=0;
		Connection con=DatabaseConnection.getConnection();
		String sql= "insert into "
				 +"enquiry(enqryId,firstName,lastName,contactNo,domain,city)"
				+"values(enqryIdSeq.nextval,?,?,?,?,?)";
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setString(1, enqry.getfName());
			ps.setString(2, enqry.getlName());
			ps.setString(3, enqry.getContactNo());
			ps.setString(4, enqry.getpDomain());
			ps.setString(5, enqry.getpLocation());
			int rows= ps.executeUpdate();
			String query= "select enqryIdseq.currval from dual";
			Statement s= con.createStatement();
			ResultSet rs= s.executeQuery(query);
				if(rs.next())
				{	enquiryId=rs.getInt(1);
					return enquiryId;
				}			
			
		} catch (SQLException e) {
			
			System.out.println(e.getMessage());
		}
	
		return 0;
	}


	


	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryId) throws ContactBookException {
EnquiryBean list= new ArrayList<EnquiryBean>();
		
		String sql="select firstName,lastName,contactNo,domain,city "
				+ " from enquiry "
			+ "  where enqryId=?";
		Connection con= DatabaseConnection.getConnection();
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setInt(1, EnquiryId);
			
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				EnquiryBean bean= new EnquiryBean();
				String type=rs.getString("firstName");
				String name= rs.getString("lastName");
				String cont= rs.getString("contactNo");
				String dom= rs.getString("domain");
				String cty= rs.getString("city");
				
			    bean.setfName(type);
				bean.setlName(name);
				bean.setContactNo(cont);
				bean.setpDomain(dom);
				bean.setpLocation(cty);
				
				
				list.add(bean);
			}
			} catch (SQLException e) {
				throw new ContactBookException(e.getMessage());
	}
			return list;
		
		}
}
		
		
			
		
	


