package com.capgemini.contactbook.test;

	import static org.junit.Assert.*;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;


		public class Test {
	
	@Test
	public void testIsvalid(){
		EnquiryBean p=new EnquiryBean();
	p.setfName("Satya");
	p.setlName("Golthi");
	p.setpLocation("Pune");
	p.setpDomain("Java");
	p.setEnquiryId(1001);
	             ContactBookService ps=new ContactBookServiceImpl();
	boolean actual=ps.isValidEnquiry(p);//1111
	boolean expected=true;//0
	assertEquals(expected,actual);
	}

}
