package com.capgemini.contactbook.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;

public class ContactBookServiceImpl implements ContactBookService{
	ContactBookDao dao;
	public ContactBookServiceImpl(){
		dao=new ContactBookDaoImpl();
	}

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		int id=dao.addEnquiry(enqry);
		return id;
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryId) throws ContactBookException {
		
		return dao.getEnquiryDetails(EnquiryId);
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry) throws ContactBookException  {
		

		Pattern pattern=Pattern.compile("[A-Z][a-z]{5,20}");
		
		Matcher matcher=pattern.matcher(enqry.getfName());
		
		if(matcher.matches()){
			Pattern pattern1=Pattern.compile("[A-Z][a-z]{5,20}");
			
			Matcher matcher1=pattern1.matcher(enqry.getlName());
			
			if(matcher1.matches()){

				Pattern pattern2=Pattern.compile("[A-Z][a-z]{5,20}");
				
				Matcher matcher2=pattern2.matcher(enqry.getpDomain());
				
				if(matcher2.matches()){
			Pattern pattern3=Pattern.compile("[0-9]{10}");
		Matcher matcher3=pattern3.matcher(enqry.getContactNo()+"");
		if(matcher3.matches()){
		String loc= enqry.getpLocation();
		if(loc.equals("Pune") || loc.equals("Chennai"))
		{
			return true;
		}
		else 
			return false;
	     }
			else
				return false;
		
		}else
			return false;
				
		}else
			return false;

}else
		return false;
	}
}


