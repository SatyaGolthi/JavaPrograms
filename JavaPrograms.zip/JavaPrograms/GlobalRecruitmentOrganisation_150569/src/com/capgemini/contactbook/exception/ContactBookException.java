package com.capgemini.contactbook.exception;

public class ContactBookException extends Exception{


public ContactBookException(String msg){
	super(msg);
}
}