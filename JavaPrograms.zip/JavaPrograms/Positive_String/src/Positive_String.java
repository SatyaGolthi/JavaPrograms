import java.util.Scanner;
public class Positive_String {

	String str;
	public Positive_String(String str) {
		this.str=str;
	}
	public boolean isPositive()
	{
		for(int i=0;i<str.length()-1;i++)
		{
			if(str.charAt(i)>str.charAt(i+1))
				return false;
		}
		return true;
	}
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a String ");
		Positive_String P = new Positive_String(in.next());
		if(P.isPositive())
		{
			System.out.println("The String is a Positive String");
		}
		else
		{
			System.out.println("The String is not a Positive String");
		}
		in.close();
	}
}
