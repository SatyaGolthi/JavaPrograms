
public class Ex {
	public float divide(int num1,int num2)
	try{
		if(num2==0)
			throw new ArthmeticException("division by zero");
		float res=num1/num2;
		return res;
	}
	public static void main(String[] args)
	{
		Ex exc=null;
		float res=exc.divide(5,0);
		System.out.println(res);
	}

}
