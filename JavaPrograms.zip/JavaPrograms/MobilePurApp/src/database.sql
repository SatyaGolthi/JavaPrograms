create table purchasedetails(purchaseid int,cname varchar(30),mailid vrchar(40),
phoneno varchar(20),purchasedate date,mobileid int references );