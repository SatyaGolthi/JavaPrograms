package com.cg.mpa.dao;

import java.util.List;

import com.cg.mpa.dto.Mobiles1;

public interface Mobiledao {
	public int addMobileDetails(Mobiles1 mob);
	public List<Mobiles1> getMobiles1(String quantity);
	public int updateMobiles(Mobiles1 mob);
	public List<Mobiles1> getMobilename();
	public int deleteRecord(int id);
	

}
