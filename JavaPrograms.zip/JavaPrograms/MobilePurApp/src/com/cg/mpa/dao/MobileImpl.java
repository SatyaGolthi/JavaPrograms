package com.cg.mpa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.mpa.dto.Mobiles1;
import com.cg.mpa.util.DatabaseConnection;

public class MobileImpl implements Mobiledao {
	public int addMobileDetails(Mobiles1 mob){
		int mobileid = 0;
		Connection con = DatabaseConnection.getConnection();
		String sql = "insert into "
				+" Mobiles1 (mobileid, name, price, quantity )"
				+" values (mobileidSeq.nextVal,?,?,?)";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, mob.getName());
			ps.setInt(2, mob.getPrice());
			ps.setString(3, mob.getQuantity());
			int rows = ps.executeUpdate();
			String query = "select mobileidSeq.currval from dual";
			Statement s =  con.createStatement();
			ResultSet rs = s.executeQuery(query);
			if(rs.next())
			{
				mobileid  = rs.getInt(1);
				return mobileid;				
			}			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}

	public List<Mobiles1> getMobiles1(String quantity){
		List<Mobiles1> list1=new ArrayList<Mobiles1>();
		Connection con = DatabaseConnection.getConnection();
		String sql = 
				"select mobileid, name, price"
				+" from mobiles1 where quantity=?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, quantity);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				Mobiles1 emp=new Mobiles1();
				int mobileid=rs.getInt("mobileId");
				String Name=rs.getString("name");
				int price=rs.getInt("price");
				emp.setMobileid(mobileid);
				emp.setName(Name);
				emp.setPrice(price);
				list1.add(emp);
			}
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
		return list1;
	}
	public int updateMobiles(Mobiles1 mob){
		Connection con = DatabaseConnection.getConnection();
		String sql ="update mobiles1 set quantity=quantity+1"
				+"where mobileId=?";
		int mobileId =1001;
		try{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, 1001);
			int rows=ps.executeUpdate();
			System.out.println(rows+"updated successfully");
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
		return 0;
	}
	public List<Mobiles1> getMobilename(){
		Connection con = DatabaseConnection.getConnection();
		String sql = "select * from mobiles1";
		try{
			Statement s=con.createStatement();
			ResultSet rs = s.executeQuery(sql);
			List<Mobiles1> list1=new ArrayList<Mobiles1>();
			while(rs.next())
			{
				Mobiles1 m1=new Mobiles1();
				m1.setMobileid(rs.getInt("mobileId"));
				m1.setName(rs.getString("name"));
				m1.setPrice(rs.getInt("price"));
				m1.setQuantity(rs.getString("quantity"));
				list1.add(m1);
			}
			return list1;
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
		return null;
	}
	public int deleteRecord(int id){
		Connection con = DatabaseConnection.getConnection();
		int resu;
		try
		{
			Statement ps=con.createStatement();
			Statement st1=con.createStatement();
			st1.executeUpdate("delete from purchasedetails where mobileid="+id);
			resu=ps.executeUpdate("delete from mobiles1 where mobileId="+id);
			return resu;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return 0;
	}
}
		
				
			