package com.cg.mpa.dao;
import java.util.List;

import com.cg.mpa.dto.PurchaseDetails1;
import com.cg.mpa.exception.PurchaseException;

public interface Purchasedao {
	public int addPurchaseDetails(PurchaseDetails1 pur)throws PurchaseException;
	
   
}
