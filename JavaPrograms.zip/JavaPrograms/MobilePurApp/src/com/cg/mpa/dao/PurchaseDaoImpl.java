package com.cg.mpa.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.List;

import com.cg.mpa.dto.PurchaseDetails1;
import com.cg.mpa.exception.PurchaseException;
import com.cg.mpa.util.DatabaseConnection;

public class PurchaseDaoImpl implements Purchasedao{
	public int addPurchaseDetails(PurchaseDetails1 purchase){
		int purchaseid=0;
		Connection con=DatabaseConnection.getConnection();
		String sql ="insert into PurchaseDetails " 
		+ " (purchaseid,cname,mailid,phoneno,purchasedate,mobileId)"
				+" values(purchaseidSeq.nextval,?,?,?,?,?)";

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,purchase.getCname());
			ps.setString(2,purchase.getMailid());
			ps.setString(3,purchase.getPhoneno());
			LocalDate date=LocalDate.now();
			Date sqlDate=Date.valueOf(date);
			ps.setDate(4, sqlDate);
			ps.setInt(5,purchase.getMobileid());
			int rows = ps.executeUpdate();
			String query = "select purchaseidSeq.currval from dual";
			Statement s = con.createStatement();
			ResultSet rs = s.executeQuery(query);
			if(rs.next())
			{
					purchaseid  = rs.getInt(1);
					return purchaseid;				
							
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			
		}
		return 0;
	}




	}

		
	

