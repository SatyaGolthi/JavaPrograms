package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.dto.Mobiles1;

public interface MobilesService {
	public int addMobileDetails(Mobiles1 mob);
	public boolean validateMobiles(Mobiles1 mob);
	public int updateMobiles(Mobiles1 mob);
	List<Mobiles1> getMobilename();
	public int deleteRecord(int id);

}
