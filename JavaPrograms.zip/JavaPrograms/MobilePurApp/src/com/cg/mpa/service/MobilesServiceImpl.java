package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.dto.Mobiles1;
import com.cg.mpa.dao.MobileImpl;


import com.cg.mpa.dao.Mobiledao;
import com.cg.mpa.dto.Mobiles1;


public class MobilesServiceImpl implements MobilesService{
	Mobiledao dao;
	public MobilesServiceImpl(){
		Mobiledao dao=new MobileImpl();
	}

	@Override
	public int addMobileDetails(Mobiles1 mob) {
		int id=dao.addMobileDetails(mob);
		// TODO Auto-generated method stub
		return id;
	}

	@Override
	public boolean validateMobiles(Mobiles1 mob) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public int updateMobiles(Mobiles1 mob) {
		Mobiledao dao=new MobileImpl();
		int id=dao.updateMobiles(mob);
		return id;
	}

	@Override
	public List<Mobiles1> getMobilename(){ 
		Mobiledao dao=new MobileImpl();
		List<Mobiles1> list=dao.getMobilename();
		// TODO Auto-generated method stub
		return list;
	}

	@Override
	public int deleteRecord(int id) {
		Mobiledao dao=new MobileImpl();
		int mobileId=dao.deleteRecord(id);
		// TODO Auto-generated method stub
		return mobileId;
	}
	

	

}
