package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.dto.PurchaseDetails1;
import com.cg.mpa.exception.PurchaseException;



public interface PurchaseService {
	public int addPurchaseDetails(PurchaseDetails1 p1)throws PurchaseException;
	public boolean validatePurchase(PurchaseDetails1 p1);

}
