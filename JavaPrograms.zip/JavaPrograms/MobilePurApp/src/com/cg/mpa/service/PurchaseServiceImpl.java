package com.cg.mpa.service;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mpa.dao.PurchaseDaoImpl;
import com.cg.mpa.dao.Purchasedao;
import com.cg.mpa.dto.PurchaseDetails1;
import com.cg.mpa.exception.PurchaseException;


public class PurchaseServiceImpl implements PurchaseService{
	Purchasedao dao;
	public PurchaseServiceImpl(){
		Purchasedao dao=new PurchaseDaoImpl();
	}
	@Override
			
	public int addPurchaseDetails(PurchaseDetails1 p1) throws PurchaseException {
		Purchasedao dao=new PurchaseDaoImpl();
		int code=dao.addPurchaseDetails(p1);
		return code;
		
	}
	public boolean validatePurchase(PurchaseDetails1 p1){
		
		
		Pattern pattern=Pattern.compile("[A-Z][a-z]{5,20}");
		
		Matcher matcher=pattern.matcher(p1.getCname());
		if(matcher.matches()){
			String mail=p1.getMailid();
			String EMAIL_REGEX="^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$";
			Pattern regex=Pattern.compile(EMAIL_REGEX,Pattern.CASE_INSENSITIVE);
			Matcher matcher2=regex.matcher(p1.getMailid());
			if(matcher2.matches()){
				Pattern pattern1=Pattern.compile("[0-9]{10}");
			Matcher matcher1=pattern1.matcher(p1.getPhoneno()+"");
			if(matcher1.matches()){
				if(p1.getMobileid()>0 && p1.getMobileid()<10000){
					return true;
				}
				else
					return false;
			}
			else
				return false;
		}
		else
			return false;
		
	}
	else
		return false;
		
	
}
}	