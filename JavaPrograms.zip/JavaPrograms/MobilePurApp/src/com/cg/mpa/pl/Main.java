package com.cg.mpa.pl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import com.cg.mpa.dto.Mobiles1;
import com.cg.mpa.dto.PurchaseDetails1;
import com.cg.mpa.exception.PurchaseException;
import com.cg.mpa.service.MobilesService;
import com.cg.mpa.service.MobilesServiceImpl;
import com.cg.mpa.service.PurchaseService;
import com.cg.mpa.service.PurchaseServiceImpl;

public class Main {
	public static void main(String args[])throws PurchaseException
	{
				Scanner sc= new Scanner(System.in);
		String cname;
		int mobileId;
		String mailId,phoneno;
		MobilesService service= new MobilesServiceImpl();
		System.out.println("Welcome to PurchaseDetails..");
		System.out.println("Select option ");
		System.out.println("1. Add Purchase Details ");
		System.out.println("2.Update Purchase details ");
		System.out.println("3.View List of Mobiles ");
		System.out.println("4. Delete records of Mobiles");
		
		int choice= sc.nextInt();
		switch(choice){
	
		case 1:
	
		System.out.println("Enter Customer name : ");
		cname=sc.next();
		System.out.println("Enter mail id:");
		mailId= sc.next();		
		System.out.println("Enter phone no:");
		phoneno= sc.next();
		System.out.println("Enter mobile id :");
        mobileId=sc.nextInt();
		PurchaseDetails1 p1=new PurchaseDetails1();
		
		p1.setCname(cname);
		p1.setMailid(mailId);
		p1.setMobileid(mobileId);
	    p1.setPhoneno(phoneno);
		PurchaseService ps= new PurchaseServiceImpl();
		boolean res= ps.validatePurchase(p1);
		System.out.println(res);
		
		if(res==true){
				int id= ps.addPurchaseDetails(p1);
					System.out.println("Details added :"+ id);
		}
		else
			System.out.println("Invalid details entered....");
		
		break;
	
		case 2:
			
			System.out.println("Enter mobileId:");
			mobileId=sc.nextInt();
			MobilesService ms=new MobilesServiceImpl();
			Mobiles1 m1=new Mobiles1();
			
			int code=ms.updateMobiles(m1);
			break;
		case 3:
			 Mobiles1  mob=new Mobiles1();
			List<Mobiles1> list1=service.getMobilename();
			if(list1==null){
				System.out.println("No records found for you");
				
				
			}
			else
			{
				for(Mobiles1 mp:list1){
					System.out.println(mp.getMobileid()+" "+mp.getName()+" "+mp.getPrice()+" "+mp.getQuantity());
				}
			}
			break;
		case 4:
			System.out.println("Enter mobileId:");
			mobileId=sc.nextInt();
			int res1=service.deleteRecord(mobileId);
			if(res1==0)
			{
				System.out.println("NoRecords found.....");
			}
			else
			{
				System.out.println("Deleted Successfully.....");
			}
			break;
		}
	}
}
			

