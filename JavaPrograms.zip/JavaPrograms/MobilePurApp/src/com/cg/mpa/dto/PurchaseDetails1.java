package com.cg.mpa.dto;

import java.time.LocalDate;

public class PurchaseDetails1 {
	private int purchaseId;
	private String cname;
	private String mailId;
	private String phoneno;
	private LocalDate purchaseDate;
	private int mobileId;
	public int getMobileid() {
		return mobileId;
	}
	public void setMobileid(int mobileid) {
		this.mobileId = mobileid;
	}
	public int getPurchaseid() {
		return purchaseId;
	}
	public void setPurchaseid(int purchaseid) {
		this.purchaseId = purchaseid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getMailid() {
		return mailId;
	}
	public void setMailid(String mailid) {
		this.mailId = mailid;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public LocalDate getPurchasedate() {
		return purchaseDate;
	}
	public void setPurchasedate(LocalDate purchasedate) {
		this.purchaseDate = purchasedate;
	}
	

}
