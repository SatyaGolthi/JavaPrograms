package com.cg.mpa.dto;

public class Mobiles1 {
	private int mobileId;
	private String name;
	private int price;
	private String quantity;
	public int getMobileid() {
		return mobileId;
	}
	public void setMobileid(int mobileid) {
		this.mobileId = mobileid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	

}
