package com.cg.mpa.exception;

public class PurchaseException extends Exception{
	
	public PurchaseException(){
	
	}
	public PurchaseException(String msg)
	{
		super(msg);
	}
}
