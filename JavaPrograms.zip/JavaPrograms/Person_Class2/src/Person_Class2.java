enum Gender
{
	M,F;
}
public class Person_Class2 
{
	private String firstName;
	private String lastName;
	private Gender gender;
	private long phonenumber;
	
public Person_Class2()
{
	System.out.println("Person Details:");
}
	public Person_Class2(String fname,String lname,Gender g,long phone)
	{
    this();
    firstName=fname;
    lastName=lname;
    gender=g;
    phonenumber=phone;
	}

public static void main(String[] args)
{
	Gender g=Gender.F;
	Person_Class2 p=new Person_Class2("Satya","Golthi",g,9834344434l);
	p.display();
}
	public void display()
	{
		System.out.println("First Name:"+firstName);
		System.out.println("Last Name:"+lastName);
		System.out.println("Gender:"+gender);
		System.out.println("Phone Number:"+phonenumber);
	}
}

