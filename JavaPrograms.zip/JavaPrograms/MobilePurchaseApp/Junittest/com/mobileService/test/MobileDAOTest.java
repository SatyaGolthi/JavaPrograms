package com.mobileService.test;

import org.junit.BeforeClass;
import org.junit.Test;

import com.mobilesales.dao.IMobileDAO;
import com.mobilesales.dao.MobileDAOImpl;
import com.mobilesales.exception.MobileException;
import com.mobilesales.service.IMobileService;
import static org.junit.Assert.fail;


public class MobileDAOTest {
	
	IMobileDAO dao=new MobileDAOImpl();
	
	@BeforeClass
	public static void setUp() {
		
	}
	
	@Test
	public void testSearchMobilesByRange() throws MobileException {
		fail("Write the Unit Test");
		
	}


}

