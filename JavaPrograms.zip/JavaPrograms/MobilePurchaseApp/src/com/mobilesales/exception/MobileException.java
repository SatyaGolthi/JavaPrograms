package com.mobilesales.exception;

/**
 * 
 * This class should have a constructor with string as argument.
 * In the constructor set the message to the parent class constructor.
 *
 */
 
 public class MobileException extends Exception
 {
     
 }