package com.mobilesales.service;

import java.util.List;

import com.mobilesales.bean.Mobile;
import com.mobilesales.bean.MobilePurchase;
import com.mobilesales.exception.MobileException;

public interface IMobileService {
	
	public int purchaseMobile(MobilePurchase purchaseObj)throws MobileException;
	public List<Mobile> searchMobilesByRange(double minPrice,double maxPrice)throws MobileException;
	

}
