package com.mobilesales.service;

import java.util.List;

import com.mobilesales.bean.Mobile;
import com.mobilesales.bean.MobilePurchase;

import com.mobilesales.exception.MobileException;


public class MobileServiceImpl implements IMobileService {
	
	/**Validate the purchase object details by invoking the validatePurchaseDetails
	 * 	method. If valid, Store the mobile purchased details into the database
	 *  by invoking DAO class method - purchaseMobile.
	 *  1. This method should return -1 if the validation fails and the
	 *  records should not get inserted into the database.
	 *  2. If the validation is success, then return the values returned from DAO
	*/
	@Override
	public int purchaseMobile(MobilePurchase purchaseObj)
			throws MobileException {
		
		return 0;
	}

    /**
	 * Retrieving the mobile details from the database for the given 
	 * 	range by invoking DAO class method - searchMobilesByRange
	 */
	@Override
	public List<Mobile> searchMobilesByRange(double minPrice, double maxPrice)
			throws MobileException {
		
		return null;
	}
	
	/**
	 * Validates the MobilePurchase object 
	*/
	public boolean validatePurchaseDetails(MobilePurchase purchaseObj)
	{
		return false;
	}

}
