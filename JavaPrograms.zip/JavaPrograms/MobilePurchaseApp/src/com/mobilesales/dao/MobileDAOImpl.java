package com.mobilesales.dao;

import java.util.List;

import com.mobilesales.bean.Mobile;
import com.mobilesales.bean.MobilePurchase;
import com.mobilesales.exception.MobileException;


public class MobileDAOImpl implements IMobileDAO{
	
	
	
	/**
	 * Validate the mobile id using the isMobileIdExists method
	 * Stores the mobile purchased details into the database. 
	 * 1. This method should return the generated purchase Id when inserted
	 * Successfully.
	 * 2. If the mobileId is not available throw MobileException with the
	 * message "Invalid Mobile Id"
	 * 3. if the mobileId exists and the quantity is zero throw MobileException with the
	 * message "Quantity not available"
	 */
	@Override
	public int purchaseMobile(MobilePurchase purchaseObj)
			throws MobileException {
		return 0;
		
	}
	
	
	/**
	 * Retrieving the mobile details from the database for the given range
	 */
	@Override
	public List<Mobile> searchMobilesByRange(double minPrice, double maxPrice)
			throws MobileException {
		return null;
		
	}
	
	/**Check whether the mobile id exists in the database.
	 */
	public Mobile isMobileIdExists(int mobileId)throws MobileException{
		
		return null;
			
	}
}

