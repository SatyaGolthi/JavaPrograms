package com.mobilesales.util;


import java.sql.DriverManager;
import java.sql.SQLException;

import javax.sql.DataSource;


public class DBHandler {
	private OracleDataSource dataSource=null;
	
	public DataSource getDataSource(){
		return dataSource;
	}
	
	public void setDataSource(OracleDataSource dataSource){
		this.dataSource=dataSource;
	}
	public DBHandler(){
		try{
			dataSource=new OracleDataSource();
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection()throws MobileException
	{
		String url="";
		String username="";
		String pwd="";
		String driver="";
		Connection con=null;
	try{
	    InputStream in=
	         new FileInputStream("./src/com.mobilesales.util/jdbc.properties");
		Properties pr=new Properties();
		try{
			pr.load(in);
		}catch(IOException e){
			Syste.out.println("There is an exception");
		}
			url=pr.getProperty("url");
			username=pr.getProperty("username");
			pwd=pr.getProperty("pwd");
			driver=pr.getProperty("driver");
			con=DriverManager.getConnection(url,username,pwd);
			
		
		System.out.println("Database connected....");
	}
	catch(ClassNotFoundException e)
	{
		System.out.println("class no loaded");
	}catch(SQLException e)
	{
		System.out.println("Not connected with DB..");
	} catch (FileNotFoundException e) {
		System.out.println("File is not found");
		// TODO Auto-generated catch block
		
	}
		return con;
	}

	public static void main(String args[])throws MobileException{
	
		getConnection();
	}

}
