package com.mobilesales.client;

import java.util.List;


import com.mobilesales.bean.Mobile;


public class TestClient {
	
	/**
	 * Get all the needed inputs to purchase a mobile.  
	 * 	Invoke the purchaseMobile method and return the corresponding 
	 * message as per the requirement in the case study
	*/
	public static String getandCheckMobilePurchase()
	{
		return null;
	}
	
	/**
	 * Get the min and max range and invoke the searchMobilesByRange
	 * 	method and return the list.
	*/
	public static List<Mobile> searchMobilesByRange()
	{
		return null;
	}

	/**
	 * Create the menu, get the choice from the user and invoke the	above methods appropriately
	*/
	public static void  main(String args[]){
		
		
	}
	
	
	
	
}
