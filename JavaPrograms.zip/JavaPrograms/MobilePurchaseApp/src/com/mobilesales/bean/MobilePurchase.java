package com.mobilesales.bean;

import java.util.Date;

public class MobilePurchase {
	
	private int purchaseId;
	private Date purchaseDate;
	private String customerName;
	private String mailId;
	private long mobileNo;
	private Mobile mobileObj;
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public Date getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public Mobile getMobileObj() {
		return mobileObj;
	}
	public void setMobileObj(Mobile mobileObj) {
		this.mobileObj = mobileObj;
	}
	
	
	

}
