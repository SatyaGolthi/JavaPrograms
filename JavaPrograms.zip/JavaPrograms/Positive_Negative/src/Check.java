public class Check
	{
	    public static void main(String[] args) 
	    {
	    	int n=Integer.parseInt(args[0]);
	        System.out.println("Enter the number you want to check:\n"+n);
	        if(n > 0)
	        {
	            System.out.println("The given number "+args[0]+" is Positive");
	        }
	        else 
	        {
	            System.out.println("The given number "+args[0]+" is Negative");
	        }
	    }
	}
	

