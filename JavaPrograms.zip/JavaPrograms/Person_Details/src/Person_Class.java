public class Person_Class {
	String firstName;
	String lastName;
	char gender;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	Person_Class()
	{
		System.out.println("firstName:"+" "+"Satya");
		System.out.println("lastName:"+" "+"Golthi");
		System.out.println("gender:"+" "+"F");
	}	
		
	Person_Class(String firstName,String lastName,char gender)	
	{
		System.out.println("\nPerson Details:");
		System.out.println("____________");
		System.out.println("            ");
		System.out.println("First Name:"+firstName);
		System.out.println("Last Name:"+lastName);
		System.out.println("Gender:"+gender);
		
	}
	public static void main(String [] args)
	{
		Person_Class a1=new Person_Class();
		Person_Class a2=new Person_Class("Pinky","Golthi",'F');
	}
	

}
