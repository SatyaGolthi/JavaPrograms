
public class Person {

	String firstName;
	String lastName;
	int age;
	float weight;
	long phoneNo;
	public enum Gender{M, F}
	Gender gender;
	
	
	public long getPhoneNo() {
		return phoneNo;
	}


	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}


	public Person()
	{
		
	}
	
	
	public Person(String firstName, String lastName, Gender gender, int age,
			float weight,long phoneNo) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.age = age;
		this.weight = weight;
		this.phoneNo=phoneNo;
	}
	
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public float getWeight() {
		return weight;
	}
	public void setWeight(float weight) {
		this.weight = weight;
	}

	
	void displayDetails(Person p1)
	{
		System.out.println("Personal Details:\n______________");
		System.out.println("\nFist Name : "+p1.getFirstName());
		System.out.println("\nLast Name :"+p1.getLastName());
		System.out.println("\nGender :"+p1.getGender());
		System.out.println("\nAge :"+p1.getAge());
		System.out.println("\nWeight :"+p1.getWeight());
		System.out.println("\nPhoneNo :"+p1.getPhoneNo());
	}

}


