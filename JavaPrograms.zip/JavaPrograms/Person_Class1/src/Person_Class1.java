
public class Person_Class1 {
			String firstName;
			String lastName;
			char gender;
			long phonenumber;
			public String getFirstName() {
				return firstName;
			}

			public void setFirstName(String firstName) {
				this.firstName = firstName;
			}

			public String getLastName() {
				return lastName;
			}

			public void setLastName(String lastName) {
				this.lastName = lastName;
			}

			public char getGender() {
				return gender;
			}

			public void setGender(char gender) {
				this.gender = gender;
			}

			public long getPhonenumber() {
				return phonenumber;
			}

			public void setPhonenumber(int phonenumber) {
				this.phonenumber = phonenumber;
			}

			Person_Class1()
			{
				System.out.println("firstName:"+" "+"Satya");
				System.out.println("lastName:"+" "+"Golthi");
				System.out.println("gender:"+" "+"F");
				System.out.println("phonenumber"+" "+"9856674675");
			}	
				
			Person_Class1(String firstName,String lastName,char gender,long phonenumber)	
			{
				System.out.println("\nPerson Details:");
				System.out.println("____________");
				System.out.println("            ");
				System.out.println("First Name:"+firstName);
				System.out.println("Last Name:"+lastName);
				System.out.println("Gender:"+gender);
				System.out.println("Phone number:"+phonenumber);
				
			}
			public static void main(String [] args)
			{
				Person_Class1 a1=new Person_Class1();
				Person_Class1 a2=new Person_Class1("Pinky","Golthi",'F',1234455555);
			}
			

		}

