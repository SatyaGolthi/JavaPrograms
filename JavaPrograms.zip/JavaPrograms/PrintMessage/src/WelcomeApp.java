
public class WelcomeApp {
public static void main(String args[]){
	System.out.println("Welcome to Tekstac");
}

}
