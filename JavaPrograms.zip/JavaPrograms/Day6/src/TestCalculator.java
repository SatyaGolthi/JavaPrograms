import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class TestCalculator {
	@Ignore
	@Test
	public void testAddForNegativeNumbers(){
		Calculator calc=new Calculator();
		int actual=calc.add(-5,-1);
		int expected=-6;
		Assert.assertEquals(expected,actual);
	}
	@Ignore
	@Test
	public void testAddForPositiveNumbers(){
	Calculator calc=new Calculator();
	int actual=calc.add(3,7);
	Assert.assertEquals(10,actual);
}
	@Test
	@Ignore
	public void testDivide(){
		Calculator calc=new Calculator();
		float actual=calc.divide(25, 5);
		Assert.assertEquals(5.0, actual,0.005);
	}
	@Test(expected=ArithmeticException.class)
	public void testDivideforZero(){
		Calculator calc=new Calculator();
		float actual=calc.divide(25, 0);
		Assert.assertEquals(5.0, actual);
	}
	@Before
	public void method(){
		System.out.println("hello");
	}
	@AfterClass
	public static void afterClassMethod(){
		System.out.println("end of testing");
	}
	@After
	public void cleanup(){
		System.out.println("cleaning...");
	}
	@BeforeClass
	public static void beforeClassMethod(){
		System.out.println("hi.......");
	}

}
