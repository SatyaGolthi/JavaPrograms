import org.junit.Test;


public class Test_DateJunit {
	
	@Test
	
	public void String(){
		
		Date p=new Date();
		
		
		
	}

}
