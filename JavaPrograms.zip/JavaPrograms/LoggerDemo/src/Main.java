import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class Main {
	static Logger lg=Logger.getLogger(Main.class);
	public static void main(String args[]){
		
		PropertyConfigurator.configure("log4j.properties");
		
		lg.debug("this is debug message");
		lg.info("this is info message");
		lg.warn("this is warn message");
		lg.error("this is error message");
		lg.fatal("this is fatal message");
		System.out.println
		("all messages except debug logged in basic log file");
		
	}

}
