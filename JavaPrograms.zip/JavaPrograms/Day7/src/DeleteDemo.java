import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
public class DeleteDemo {
	
public static void main(String args[]){
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Location:");
	String loc=sc.next();
	
	String sql="delete from employees where location=?";
	Connection con=DatabaseConnection.getConnection();
	try{
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, loc);
		int rows=ps.executeUpdate();
		System.out.println(rows+ "rows deleted...");
	}catch(SQLException e){
		System.out.println(e.getMessage());
	}
}
}
