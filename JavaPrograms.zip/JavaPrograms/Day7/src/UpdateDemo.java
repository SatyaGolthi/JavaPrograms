import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;


public class UpdateDemo {
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter percentage:");
		int percent=sc.nextInt();
		
		String sql="update employees set salary=salary+(salary*?)/100"
				   +"where empid=?";
		Connection con=DatabaseConnection.getConnection();
		try{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, percent);
			ps.setInt(2,3);
			int rows=ps.executeUpdate();
			System.out.println(rows+"rows updated...");
		}catch (SQLException e){
			System.out.println(e.getMessage());
		}
	}

}
