
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SelectDemo
{

	public static void main(String args[])
	{
		String sql="select empid,empname  as Name from "
				+"employees where location=?";
		String location="Hyd";
		Connection con=DatabaseConnection.getConnection();
		try{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, location);
			ResultSet rs=ps.executeQuery();
			int status=0;
			while(rs.next())
			{
				int id=rs.getInt("empid");
				String name=rs.getString("Name");
				System.out.println(id+ " " +name);
				status=1;
			}
			if(status==0)
				System.out.println("No Employee For this location");
			rs.close();
		}
		
			catch(SQLException e){
				System.out.println(e.getMessage());
				
			}
		}
	
}