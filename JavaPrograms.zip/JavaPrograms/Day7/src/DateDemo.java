	import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
public class DateDemo {

		
		public static void main(String args[])
		{
			Connection con=DatabaseConnection.getConnection();
			int empid;
			String name;
			double salary;
			String loc;
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter name: ");
			name=sc.next();
			System.out.println("Enter employee id: ");
			empid=sc.nextInt();
			System.out.println("Enter Salary:");
			salary=sc.nextDouble();
			System.out.println("Enter Location:");
			loc=sc.next();
			System.out.println("Enter date(dd/MM/yyyy)");
			String dt=sc.next();
			
			DateTimeFormatter formatter=
					DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate joindate=LocalDate.parse(dt,formatter);
			Date sqlDate=Date.valueOf(joindate);
			
			String sql="insert into "
					+"employees(empid,empname,salary,location,joindate)"
					+"values(?,?,?,?,?)";
			try{
				PreparedStatement ps=con.prepareStatement(sql);
				ps.setInt(1,empid);
				ps.setString(2, name);
				ps.setDouble(3, salary);
				ps.setString(4, loc);
				ps.setDate(5,sqlDate);
			
				int rows=ps.executeUpdate();
				System.out.println(rows+"record inserted successfully");
			}catch(SQLException e){
				System.out.println(e.getMessage());
			}
		}

	}


