
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class InsertDemo { 
	
	public static void main(String args[])
	{
		Connection con=DatabaseConnection.getConnection();
		int empid;
		String name;
		double salary;
		String loc;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name: ");
		name=sc.next();
		System.out.println("Enter employee id: ");
		empid=sc.nextInt();
		System.out.println("Enter Salary:");
		salary=sc.nextDouble();
		System.out.println("Enter Location:");
		loc=sc.next();
		
		String sql="insert into "
				+"employees(empid,empname,salary,location)"
				+"values(?,?,?,?)";
		try{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1,empid);
			ps.setString(2, name);
			ps.setDouble(3, salary);
			ps.setString(4, loc);
		
		
			int rows=ps.executeUpdate();
			System.out.println(rows+"record inserted successfully");
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
	}

}
