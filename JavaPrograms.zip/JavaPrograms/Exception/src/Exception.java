
public class Exception {

}
